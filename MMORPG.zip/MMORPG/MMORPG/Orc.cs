﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMORPG
{
    public class Orc : IRace
    {
        public int Health { get; set; } = 150;
        public int Mana { get; set; } = 100;

        public Hunter CreateHunter()
        {
            return new Hunter() { ClassName = "Orc" };
        }
        public Warrior CreateWarrior()
        {
            return new Warrior() { ClassName = "Orc" };
        }
        public Mage CreateMage()
        {
            return new Mage() { ClassName = "Orc" };
        }
    }
}
