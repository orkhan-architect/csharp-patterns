﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMORPG
{
    public interface IRace
    {
        public int Health { get; set; }
        public int Mana { get; set; }

        public Warrior CreateWarrior();
        public Hunter CreateHunter();
        public Mage CreateMage();
    }
}
