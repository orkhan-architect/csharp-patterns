﻿using System;

namespace MMORPG;

class Program
{
    public static int Damage(int attack, int enemyDefense)
    {
        int damage = 0;

        if(attack > enemyDefense)
            damage = (attack - enemyDefense);

        return damage;
    }
    public static void Main()
    {
        IRace myRace = new Elf();
        Warrior myWarrior = myRace.CreateWarrior();
        Console.WriteLine("My hero: " + myWarrior.ClassName);
        Console.WriteLine("My hero class: " + myWarrior.Name);
        myWarrior.Combat();
        myWarrior.Armor();
        myWarrior.Weapon();
        myWarrior.Resource();

        IRace enemyRace = new Draenei();
        Mage enemyMage = enemyRace.CreateMage();
        Console.WriteLine("\nEnemy hero: " + enemyMage.ClassName);
        Console.WriteLine("Enemy hero class: " + enemyMage.Name);
        enemyMage.Combat();
        enemyMage.Armor();
        enemyMage.Weapon();
        enemyMage.Resource();

        int myDamage = Damage(myWarrior.AttackPower, enemyMage.DefensePower);
        int enemyDamage = Damage(enemyMage.AttackPower, myWarrior.DefensePower);

        int move = 0;

        Random rand = new Random();
        int mapDistance = 0;

        Console.WriteLine("\nGame is running");

        while(myRace.Health > 0 && enemyRace.Health > 0)
        {
            move++;
            mapDistance = rand.Next(0, 5);

            if(myWarrior.AttackDistance >= mapDistance)
            {
                enemyRace.Health -= myDamage;

                if(enemyRace.Health < 0)
                    break;
            }

            if(enemyMage.AttackDistance >= mapDistance)
            {
                myRace.Health -= enemyDamage;
                enemyRace.Mana -= 20;

                if (myRace.Health < 0)
                    break;
            }

            enemyRace.Mana += 10;

            if(enemyRace.Health < 50)
            {
                enemyRace.Mana -= 20;
                enemyRace.Health += enemyMage.Heal(enemyRace.Mana);
            }
        }

        Console.WriteLine("\nGame is ended");

        if(enemyRace.Health < 0)
        {
            Console.WriteLine("You won this game in " + move + ". move");
        }
        else
        {
            Console.WriteLine("You lose this game in " + move + ". move");
        }
    }
}