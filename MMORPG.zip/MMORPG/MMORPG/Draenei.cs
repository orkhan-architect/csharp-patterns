﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMORPG
{
    public class Draenei : IRace
    {
        public int Health { get; set; } = 180;
        public int Mana { get; set; } = 100;

        public Hunter CreateHunter()
        {
            return new Hunter() { ClassName = "Draenei" };
        }
        public Warrior CreateWarrior()
        {
            return new Warrior() { ClassName = "Draenei" };
        }
        public Mage CreateMage()
        {
            return new Mage() { ClassName = "Draenei" };
        }
    }
}
