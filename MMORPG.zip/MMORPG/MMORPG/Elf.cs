﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMORPG
{
    public class Elf : IRace
    {
        public int Health { get; set; } = 120;
        public int Mana { get; set; } = 150;

        public Hunter CreateHunter()
        {
            return new Hunter() { ClassName = "Elf" };
        }
        public Warrior CreateWarrior()
        {
            return new Warrior() { ClassName = "Elf" };
        }
        public Mage CreateMage()
        {
            return new Mage() { ClassName = "Elf" };
        }
    }
}
