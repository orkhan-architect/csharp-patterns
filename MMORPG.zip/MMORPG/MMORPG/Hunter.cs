﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMORPG
{
    public class Hunter : IRaceClass
    {
        public string Name { get; set; } = "Hunter";
        public string ClassName { get; set; }
        public int AttackPower { get; set; } = 20;
        public int DefensePower { get; set; } = 10;
        public int AttackDistance { get; set; } = 3;

        public void Armor()
        {
            Console.WriteLine("Mail");
        }

        public void Combat()
        {
            Console.WriteLine("Damage");
        }

        public void Resource()
        {
            Console.WriteLine("Health, Focus");
        }

        public void Weapon()
        {
            Console.WriteLine("Axes, Bows, Crossbows, Daggers, Fist Weapons, Guns, Polearms, Staves, Swords");
        }
    }
}
