﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMORPG
{
    public class Dwarf : IRace
    {
        public int Health { get; set; } = 80;
        public int Mana { get; set; } = 80;

        public Hunter CreateHunter()
        {
            return new Hunter() { ClassName = "Dwarf" };
        }
        public Warrior CreateWarrior()
        {
            return new Warrior() { ClassName = "Dwarf" };
        }
        public Mage CreateMage()
        {
            return new Mage() { ClassName = "Dwarf" };
        }
    }
}
