﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMORPG
{
    public interface IRaceClass
    {
        public string Name { get; set; }
        public string ClassName { get; set; }
        public int AttackPower { get; set; }
        public int DefensePower { get; set; }
        public int AttackDistance { get; set; }
        
        public void Combat();
        public void Resource();
        public void Armor();
        public void Weapon();
    }
}
