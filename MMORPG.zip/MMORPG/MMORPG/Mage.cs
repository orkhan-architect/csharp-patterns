﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMORPG
{
    public class Mage : IRaceClass
    {
        public string Name { get; set; } = "Mage";
        public string ClassName { get; set; }
        public int AttackPower { get; set; } = 25;
        public int DefensePower { get; set; } = 5;
        public int AttackDistance { get; set; } = 5;

        public void Armor()
        {
            Console.WriteLine("Cloth");
        }

        public void Combat()
        {
            Console.WriteLine("Damage");
        }

        public void Resource()
        {
            Console.WriteLine("Health, Mana");
        }

        public void Weapon()
        {
            Console.WriteLine("Wands, Daggers, One-Handed Swords, Staves");
        }

        public int Heal(int raceMana)
        {
            int raceHealth = 0;
            if (raceMana > 30)
            {
                raceHealth += 10;
            }

            return raceHealth;
        }
    }
}
