﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMORPG
{
    public class Human : IRace
    {
        public int Health { get; set; } = 100;
        public int Mana { get; set; } = 100;

        public Hunter CreateHunter()
        {
            return new Hunter() { ClassName = "Human" };
        }
        public Warrior CreateWarrior()
        {
            return new Warrior() { ClassName = "Human" };
        }
        public Mage CreateMage()
        {
            return new Mage() { ClassName = "Human" };
        }
    }
}
