﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMORPG
{
    public class Warrior : IRaceClass
    {
        public string Name { get; set; } = "Warrior";
        public string ClassName { get; set; }
        public int AttackPower { get; set; } = 15;
        public int DefensePower { get; set; } = 15;
        public int AttackDistance { get; set; } = 0;
        
        public void Armor()
        {
            Console.WriteLine("Plate, Shields");
        }

        public void Combat()
        {
            Console.WriteLine("Tank, Damage");
        }

        public void Resource()
        {
            Console.WriteLine("Health, Rage");
        }

        public void Weapon()
        {
            Console.WriteLine("Daggers, Fist Weapons, Axes, Maces, Swords, Polearms, Staves");
        }
    }
}
