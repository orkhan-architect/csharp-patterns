﻿using System;
using System.Collections.Generic;

namespace SportChain;

public interface IHandler
{
    IHandler SetNext(IHandler handler);
    object Handle(object request);
}

abstract class AbstractHandler : IHandler
{
    private IHandler _nextHandler;    

    public IHandler SetNext(IHandler handler)
    {
        _nextHandler = handler;
        return handler;
    }

    public virtual object Handle(object request)
    {
        if (_nextHandler != null)
            return _nextHandler.Handle(request);
        else
            return null;
    }
}

class TrainingHandler : AbstractHandler
{
    public override object Handle(object request)
    {
        if ((request as string) == "Stretch")
            return $"My sport was started with {request.ToString()}.\n";
        else
            return base.Handle(request);
    }
}

class CardioHandler : AbstractHandler
{
    public override object Handle(object request)
    {
        if (Convert.ToByte(request) == 5)
            return $"During cardio usually my endurance is {request.ToString()}.\n";
        else
            return base.Handle(request);
    }
}

class BarbellHandler : AbstractHandler
{
    public override object Handle(object request)
    {
        if (Convert.ToByte(request) >= 10)
            return $"My power of weightlifting rose to {request.ToString()}.\n";
        else
            return base.Handle(request);
    }
}

class Sportsman
{
    public static void SportRoutine(AbstractHandler handler)
    {
        foreach (var routine in new List<string> { "Stretch", "5", "10" })
        {
            if(routine == "Stretch")
                Console.WriteLine($"Did you do body {routine}?");
            else if(Convert.ToByte(routine) == 5)
                Console.WriteLine($"Is your endurance for cardio is {routine}?");
            else if (Convert.ToByte(routine) >= 10)
                Console.WriteLine($"Is your power for weightlifting is higher than {routine}?");

            var result = handler.Handle(routine);

            if (result != null)
            {
                Console.WriteLine(result);
            }                
            else { 
                if (routine != "Stretch")
                    Console.WriteLine($" {routine} is not in sport list");
                else if (Convert.ToByte(routine) != 5)
                    Console.WriteLine($"Your endurance for cardio is distinct - {routine}?");
                else if (Convert.ToByte(routine) < 10)
                    Console.WriteLine($"Your power for weightlifting is less - {routine}?");
            }
        }
    }
}

class Program
{
    public static void Main(string[] args)
    {
        var training = new TrainingHandler();
        var cardio = new CardioHandler();
        var barbell = new BarbellHandler();

        training.SetNext(cardio).SetNext(barbell);

        Console.WriteLine("Chain: training > cardio > barbell\n");
        Sportsman.SportRoutine(training);
    }
}