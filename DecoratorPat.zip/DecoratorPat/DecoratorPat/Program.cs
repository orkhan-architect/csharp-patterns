﻿using System;

namespace DecoratorPat;

public abstract class PizzaComponent
{
    public abstract string Operation();
}

class ConcreteComponent : PizzaComponent
{
    string _concComponent;
    public ConcreteComponent(string concComponent)
    {
        _concComponent = concComponent;
    }

    public override string Operation()
    {
        return _concComponent;
    }
}

abstract class Pizza : PizzaComponent
{
    protected PizzaComponent _pizzaComponent;

    public Pizza(PizzaComponent pizzaComponent)
    {
        _pizzaComponent = pizzaComponent;
    }

    public void SetComponent(PizzaComponent pizzaComponent)
    {
        _pizzaComponent = pizzaComponent;
    }

    public override string Operation()
    {
        if (_pizzaComponent != null)
        {
            return _pizzaComponent.Operation();
        }
        else
        {
            return string.Empty;
        }
    }
}

class Mexicano : Pizza
{
    public Mexicano(PizzaComponent comp) : base(comp) { }

    public override string Operation()
    {
        return $"Mexicano({base.Operation()})";
    }
}

class AmericanHot : Pizza
{
    public AmericanHot(PizzaComponent comp) : base(comp) { }

    public override string Operation()
    {
        return $"AmericanHot({base.Operation()})";
    }
}

public class Client
{
    public void ClientCode(PizzaComponent component)
    {
        Console.WriteLine("RESULT: " + component.Operation());
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        Client client = new Client();

        var simple = new ConcreteComponent("Mexicano topper");
        
        client.ClientCode(simple);
        Console.WriteLine();

        Mexicano pizzaMexicano = new Mexicano(simple);
        AmericanHot pizzaAmericanHot = new AmericanHot(pizzaMexicano);

        client.ClientCode(pizzaAmericanHot);
    }
}
