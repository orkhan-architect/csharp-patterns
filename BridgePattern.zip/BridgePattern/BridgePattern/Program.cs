﻿using System;

namespace BridgePattern;

public interface IImplementation
{
    string OperationImplementation(string name);
}

class AirTransport
{
    protected IImplementation _implementation;

    public AirTransport(IImplementation implementation)
    {
        _implementation = implementation;
    }

    public virtual string Operation(string name)
    {
        return "Main feature:\n" + _implementation.OperationImplementation(name);
    }
}

class ExtendedAirTransport : AirTransport
{
    public ExtendedAirTransport(IImplementation implementation) : base(implementation) { }

    public override string Operation(string name)
    {
        return "Extended feature:\n" + base._implementation.OperationImplementation(name);
    }
}

class AirTransportType : IImplementation
{
    public string OperationImplementation(string name)
    {
        return "Air transport type: " + name + "\n";
    }
}

class AirTransportCarriage : IImplementation
{
    public string OperationImplementation(string name)
    {
        return "This air transport carriage type: " + name + "\n";
    }
}

class Client
{
    public void ClientCode(AirTransport airTransport, string name)
    {
        Console.WriteLine(airTransport.Operation(name));
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        Client client = new Client();

        AirTransport airTransport;

        airTransport = new AirTransport(new AirTransportType());
        client.ClientCode(airTransport, "F15");

        Console.WriteLine();

        airTransport = new ExtendedAirTransport(new AirTransportCarriage());
        client.ClientCode(airTransport, "Armor");
    }
}
